// 3af20681-fc11-4e19-8bdc-f7416d37cf61		Administrators
// 03a3c34f-f5a4-461f-8179-21710a52f22d		Anonymous Users
// ff54f608-70df-4637-81f7-dc40dc1b7d34		Authenticated Users
// 618187bb-b32b-4b4a-aba0-8a9771b46602		Blog Authors
// 60e0ef86-4a31-e911-a964-000d3a378ca2		CEO Blog Author
// 5bd1f11a-73a2-eb11-b1ac-0022480897c8		Consultant
// 155ac4fa-0410-e811-8105-3863bb35cc58		Content Author
// 0fe857b8-848e-e911-a973-000d3a378dd3		Content Preview
// afb83f89-e3f0-e811-a961-000d3a378f36		Customer Self Service Admin
// cc54bb9f-e1b2-e911-a839-000d3a315cfc		Educator
// 93c16008-d227-4e54-8f35-b994866a8086		Event Managers
// 3344f0b8-865b-eb11-a812-002248029f09		Intern
// f2db1fe1-d74f-e911-a972-000d3a37870e		Student Supported Access
// 33d05187-37a1-eb11-b1ac-0022480897c8		Super Admin
// db0fd7ff-fefe-e811-a964-000d3a378dd3		Supported Users LMx
// e6074e45-d830-ea11-a810-000d3a598e50		Supported Users ZOB
// c40fd448-f3c6-e811-a95e-000d3a378ca2		Supported Users ZOS
// e2ce2d9a-82ef-e911-a840-000d3a315241		Supported Users ZOV
// d271ea1f-aeec-e811-a961-000d3a37870e		Temp Supported Users
// 5af38932-8dff-e811-a964-000d3a378dd3		Zemax Staff

export const webRolesJa = [
	{
		role: 'Customer Self Service Admin',
		roleid: 'afb83f89-e3f0-e811-a961-000d3a378f36',
		display: 'あなたはライセンス管理者です',
		description: 'つまり、アカウントに新しい同僚を追加したり、以前の同僚の記録を無効化したり、使用中のライセンスを確認したり、同僚をライセンスのエンド ユーザーとして追加または削除したりできます。 サポートされているライセンスのいずれかに対して新しいチケットを作成できます。'
	},
	{
		role: 'Super Admin',
		roleid: '33d05187-37a1-eb11-b1ac-0022480897c8',
		display: 'あなたはスーパー管理者です',
		description: 'これは、組織内のすべてのユーザーとライセンスを管理できることを意味します。'
	},
	{
		role: 'Supported Users ZOS',
		roleid: 'c40fd448-f3c6-e811-a95e-000d3a378ca2',
		display: 'サポートされている OpticStudio ライセンスのエンド ユーザーである',
		description: 'つまり、OpticStudio ナレッジベースの記事、Zemax コミュニティ フォーラムに完全にアクセスでき、サポートされている OpticStudio ライセンスに対して新しいチケットを開くことができます。'
	},
	{
		role: 'Supported Users ZOB',
		roleid: 'e6074e45-d830-ea11-a810-000d3a598e50',
		display: 'あなたは、サポートされている OpticsBuilder ライセンスのエンド ユーザーです。',
		description: 'これは、OpticsBuilder ナレッジベース記事、Zemax コミュニティ フォーラムへのフル アクセスがあり、サポートされている OpticsBuilder ライセンスに対して新しいチケットを開くことができることを意味します。'
	},
	{
		role: 'Supported Users ZOV',
		roleid: 'e2ce2d9a-82ef-e911-a840-000d3a315241',
		display: 'あなたはサポートされている OpticsViewer ライセンスのエンド ユーザーです',
		description: 'これは、Zemax コミュニティ フォーラムとすべての OpticsViewer ナレッジベース記事に完全にアクセスできることを意味します。'
	},
	{
		role: 'Supported Users LMx',
		roleid: 'db0fd7ff-fefe-e811-a964-000d3a378dd3',
		display: 'あなたは、サポートされている LensMechanix ライセンスのエンド ユーザーです。',
		description: 'つまり、LensMechanix ナレッジベースの記事とフォーラムに完全にアクセスできます。 サポートされている LensMechanix ライセンスに対して新しいケースを開くこともできます。'
	},
	{
		role: 'Educator',
		roleid: 'cc54bb9f-e1b2-e911-a839-000d3a315cfc',
		display: 'あなたは教育者です',
		description: 'これは、あなたの教育機関の学生を表示できることを意味します。'
	},
	{
		role: 'Student Supported Access',
		roleid: 'f2db1fe1-d74f-e911-a972-000d3a37870e',
		display: 'あなたはグローバル アカデミック プログラム ライセンスを持つ学生です。',
		description: 'つまり、ナレッジベースの記事に完全にアクセスでき、Zemax コミュニティ フォーラムに参加できますが、グローバル アカデミック プログラム ライセンスを使用して、当社のエンジニアにサポート チケットを発行することはできません。 ソフトウェアについてサポートが必要な場合は、チューターに相談するか、Zemax コミュニティに問い合わせてください。'
	},
	{
		role: 'Temp Supported Users',
		roleid: 'd271ea1f-aeec-e811-a961-000d3a37870e',
		display: '一時的にサポートされているアクセスがあります',
		description: 'これは、限られた時間だけ、ナレッジベースの記事と Zemax コミュニティ フォーラムに完全にアクセスできることを意味します。 長期サポート アクセスのオプションについては、アカウント マネージャーと話し合うことができます。'
	},
	{
		role: 'undefined',
		display: 'あなたはサポートされていません',
		description: 'つまり、ナレッジベース記事と Zemax コミュニティ フォーラムへのアクセスが制限され、新しいチケットを開くことができなくなります。サポート対象の顧客になるには、ライセンス管理者またはエンド ユーザーであるサポート契約またはライセンスのサブスクリプション期間を延長するか、既存のサポート対象ライセンスのエンド ユーザーとして追加する必要があります。'
	},
	{
		role: 'Administrators',
		roleid: '3af20681-fc11-4e19-8bdc-f7416d37cf61',
		display: 'Administrators',
		description: ''
	},
	{
		role: 'Anonymous Users',
		roleid: '03a3c34f-f5a4-461f-8179-21710a52f22d',
		display: 'Anonymous Users',
		description: ''
	},
	{
		role: 'Authenticated Users',
		roleid: 'ff54f608-70df-4637-81f7-dc40dc1b7d34',
		display: 'Authenticated Users',
		description: ''
	},
	{
		role: 'Blog Authors',
		roleid: '618187bb-b32b-4b4a-aba0-8a9771b46602',
		display: 'Blog Authors',
		description: ''
	},
	{
		role: 'CEO Blog Author',
		roleid: '60e0ef86-4a31-e911-a964-000d3a378ca2',
		display: 'CEO Blog Author',
		description: ''
	},
	{
		role: 'Consultant',
		roleid: '5bd1f11a-73a2-eb11-b1ac-0022480897c8',
		display: 'Consultant',
		description: ''
	},
	{
		role: 'Content Author',
		roleid: '155ac4fa-0410-e811-8105-3863bb35cc58',
		display: 'Content Author',
		description: ''
	},
	{
		role: 'Content Preview',
		roleid: '0fe857b8-848e-e911-a973-000d3a378dd3',
		display: 'Content Preview',
		description: ''
	},
	{
		role: 'Event Managers',
		roleid: '93c16008-d227-4e54-8f35-b994866a8086',
		display: 'Event Managers',
		description: ''
	},
	{
		role: 'Intern',
		roleid: '3344f0b8-865b-eb11-a812-002248029f09',
		display: 'Intern',
		description: ''
	},
	{
		role: 'Zemax Staff',
		roleid: '5af38932-8dff-e811-a964-000d3a378dd3',
		display: 'Zemax Staff',
		description: ''
	}
]
