import {createContext} from "react";

const ContextPage = createContext();

export default ContextPage;
