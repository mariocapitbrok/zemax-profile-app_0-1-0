import React, { useCallback, useEffect, useState } from "react";
import {
	Card,
	Tabs,
	Spinner,
	DisplayText
} from "@shopify/polaris";
import { useAuthorizedApi } from '../api/useAuthorizedApi';
import { useAuth0 } from "@auth0/auth0-react";
import TableCompanyLicenses from "./TableCompanyLicenses";
import TableCompanyCommercialLicenses from "./TableCompanyCommercialLicenses";
import TableMyLicensesAdmin from "./TableMyLicensesAdmin";
import TableMyLicenses from "./TableMyLicenses";
import TableMyEducationalLicenses from "./TableMyEducationalLicenses";
import TableMyCommercialLicenses from './TableMyCommercialLicenses';
import TableMyLicensesStudent from './TableMyLicensesStudent';
import { useRecoilState, useRecoilValue, useSetRecoilState } from "recoil";
import {
	contactidValue,
	dateLockBannerState, endUserDateState,
	licensesObjectAtom, lockTransferState, showLockBannerState,
	updateLicensesTable
} from "../atoms/profileAtom";
import { FormattedMessage } from "react-intl";

export default function LicenseTable () {
	const { user } = useAuth0();
	const azureBaseURL = process.env.REACT_APP_AZURE_BASE_URL;
	// const azureBaseURL = 'http://localhost:7071/api/';
	// const userName = 'auth0|5f974066b41d7d006ead46dd'; // Aaron user
	const { get } = useAuthorizedApi( azureBaseURL );
	// const [ active, setActive ] = useState( false );
	const [ isLoaded, setIsLoaded ] = useState( false );
	const [ licensesObject, setLicensesObject ] = useRecoilState( licensesObjectAtom );
	const updateLicenses = useRecoilValue( updateLicensesTable );
	const contactid = useRecoilValue( contactidValue );
	const [ endUsersData, setEndUsersData ] = useRecoilState( endUserDateState );
	const setLockTransfer = useSetRecoilState( lockTransferState );
	const setDateLockBanner = useSetRecoilState( dateLockBannerState );
	const setShowLockBanner = useSetRecoilState( showLockBannerState );

	useEffect( () => {
		get( 'dynamics_get_licenses_by_auth0id', { auth0_id: user.sub } ).then( ( { data: val } ) => {
			console.warn( val );
			// console.log( value['new_jobfunction'] );
			setLicensesObject( val );
		} ).finally( () => {
			setIsLoaded( true );
		} );

		setEndUsersData( {
			license_detail: {},
			users: {},
			licenseid: ''
		} )
		setDateLockBanner( '' );
		setShowLockBanner( false )

	}, [ contactid, updateLicenses ] );

	useEffect( () => {
		setLockTransfer( false );
		setDateLockBanner( '' );

	}, [ endUsersData, licensesObject ] )


	function TabsLicenses () {
		const [ selectedTab, setSelectedTab ] = useState( 0 );
		const handleTabChange = useCallback(
			( selectedTabIndex ) => setSelectedTab( selectedTabIndex ),
			[ licensesObject ],
		);

		let tabsLicense = [];
		if ( licensesObject.new_jobfunction === "Student" ) {
			tabsLicense = tabsLicense.concat(
				{
					id: 'tab2',
					title: <FormattedMessage id="myLicense"
											 defaultMessage="My Licenses (End User)" />,
					content: <FormattedMessage id="myLicense"
											   defaultMessage="My Licenses (End User)" />,
					element: <TableMyLicensesStudent />,
				}
			)

		}
		if ( (licensesObject.new_jobfunction === "Educator" && licensesObject.new_customertype === "Educational") ) {
			console.log( 'Educator Educational' );
			tabsLicense = tabsLicense.concat(
				{
					id: 'tab2',
					title: <FormattedMessage id="myEducationalLicenses"
											 defaultMessage="My Educational Licenses" />,
					content: <FormattedMessage id="myEducationalLicenses"
											   defaultMessage="My Educational Licenses" />,
					element: <TableMyEducationalLicenses />,
				}
			)
		}

		if ( licensesObject.company_licenses_commercial && licensesObject.company_licenses_commercial.length ) {
			console.log( 'Commercial' );
			tabsLicense = tabsLicense.concat(
				{
					id: 'tab3',
					title: <FormattedMessage id="companyLicensesCommercial"
											 defaultMessage="Company Licenses Commercial" />,
					content: <FormattedMessage id="companyLicensesCommercial"
											   defaultMessage="Company Licenses Commercial" />,
					element: <TableCompanyCommercialLicenses />,
				},
				{
					id: 'tab4',
					title: 'My Licenses Commercial',
					content: 'My Licenses Commercial',
					element: <TableMyCommercialLicenses />,
				},
				{
					id: 'tab0',
					title: <FormattedMessage id="myOrganizationLicenses"
											 defaultMessage="My Organization's Licenses" />,
					content: <FormattedMessage id="myOrganizationLicenses"
											   defaultMessage="My Organization's Licenses" />,
					element: <TableCompanyLicenses />,
				}
			)
		}
		if ( licensesObject.my_licenses_admin && licensesObject.my_licenses_admin.length ) {
			// console.log( 'My Admin' );
			tabsLicense = tabsLicense.concat(
				{
					id: 'tab5',
					title: <FormattedMessage id="myLicenseAdmin"
											 defaultMessage="My Licenses (Admin)" />,
					content: <FormattedMessage id="myLicenseAdmin"
											   defaultMessage="My Licenses (Admin)" />,
					element: <TableMyLicensesAdmin />,
				}
			)
		}
		if ( licensesObject.my_licenses && licensesObject.my_licenses.length && licensesObject.new_jobfunction !== "Student" ) {
			tabsLicense = tabsLicense.concat(
				{
					id: 'tab6',
					title: <FormattedMessage id="myLicense"
											 defaultMessage="My Licenses (End User)" />,
					content: <FormattedMessage id="myLicense"
											   defaultMessage="My Licenses (End User)" />,
					element: <TableMyLicenses />
				}
			)
		}
		if ( licensesObject.company_licenses && licensesObject.company_licenses.length && licensesObject.new_jobfunction !== "Student" ) {
			tabsLicense = tabsLicense.concat(
				{
					id: 'tab7',
					title: <FormattedMessage id="companyLicense" defaultMessage="Company Licenses" />,
					content: <FormattedMessage id="companyLicense" defaultMessage="Company Licenses" />,
					element: <TableCompanyLicenses />
				}
			)
		}

		if ( tabsLicense.length ) {
			return <Card>
				<Tabs selected={selectedTab}
					  onSelect={handleTabChange}
					  tabs={tabsLicense}
					  title={tabsLicense[ selectedTab ].content}
				>
				</Tabs>
				{tabsLicense[ selectedTab ].element}
			</Card>
		}

		return (
			<DisplayText size="small">
				<FormattedMessage id="noRecords" defaultMessage="There are no records to display." />
			</DisplayText>
		)
	}

	return (
		<>
			{!isLoaded ? <Spinner size="small" /> : <TabsLicenses />}
			<div style={{ marginBottom: "20px" }} />
		</>
	);
}
