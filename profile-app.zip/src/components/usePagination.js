import { useCallback, useMemo, useState } from "react";


export default function usePagination ( data, perPage = 5 )
{
	const [ page, setPage ] = useState( 1 )
	const maxPages = Math.ceil( data.length / perPage )

	const paged = useMemo( () => {
		return data.slice(
			(page - 1) * perPage,
			page * perPage
		)
	}, [ page, data ] )

	const handlePagination = useCallback( ( direction ) => {
		if ( direction === 'next' ) {
			setPage( curr => Math.min( curr + 1, maxPages ) )
		} else {
			setPage( curr => Math.max( curr - 1, 1 ) )
		}
	}, [ maxPages ] )


	return {
		paged,
		page,
		maxPages,
		handlePagination
	}
}
