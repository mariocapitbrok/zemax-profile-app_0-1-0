import { Toast } from "@shopify/polaris";
import React from "react";
import { useRecoilState } from "recoil";
import { toastState } from "../atoms/profileAtom";
import { toastErrorState } from "../atoms/profileAtom";
import { toastApiMessageState } from "../atoms/profileAtom";

export default function Toaster () {

	const [ apiMessage, setApiMessage ] = useRecoilState( toastApiMessageState );
	const [ toastActive, setToastActive ] = useRecoilState( toastState );
	const [ toastError, setToastError ] = useRecoilState( toastErrorState );

	const handleClose = () => {
		setApiMessage( '' );
		setToastError( false );
		setToastActive( false );
	}

	const toastMarkup = toastActive ?
		<Toast
			duration={4200}
			content={apiMessage}
			onDismiss={handleClose}
			error={toastError}
		/> : null;

	return <div>
		{toastMarkup}
	</div>;
}
