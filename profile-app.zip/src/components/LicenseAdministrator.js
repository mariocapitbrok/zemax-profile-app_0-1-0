import { AppProvider, DisplayText } from "@shopify/polaris";
import Link from "./Link";
import LicensesTable from "./LicensesTable";
import React, { useEffect, useRef } from "react";
import enTranslations from '@shopify/polaris/locales/en.json';
import { useRecoilState, useRecoilValue, useSetRecoilState } from "recoil";
import { activeComponentAtom, contactidValue, webRoleAdministrator, webRoleTemp } from "../atoms/profileAtom";
import { FormattedMessage } from "react-intl";

export default function LicensesAdministrator () {
	const licenseRef = useRef();
	const isAdmin = useRecoilValue( webRoleAdministrator );
	const isTemp = useRecoilValue( webRoleTemp );
	const setActiveComponent = useSetRecoilState( activeComponentAtom );
	let contactidLocal = window.localStorage.getItem( 'contactid' );
	const [ contactid, setContactid ] = useRecoilState( contactidValue );

	useEffect( () => {
		setContactid( contactidLocal );
	}, [] )

	useEffect( () => {
		if ( window.location.hash === '#license-table' && licenseRef.current ) {

			setTimeout( () => {
				const { offsetTop } = licenseRef.current || 0;
				//console.log( offsetTop )
				window.scrollTo( 0, offsetTop );
			}, 2500 )
		}
	}, [] )

	const handleGoPage = ( page, e ) => {
		e.preventDefault();
		window.location.hash = '';
		setActiveComponent( page )
	}

	return (
		<AppProvider i18n={enTranslations}>
			<div id="license-table" ref={licenseRef}>
				<DisplayText size="large">
					<FormattedMessage id="licenses"
									  defaultMessage="Licenses" />
				</DisplayText>
				<div style={{ textAlign: "right", marginBottom: "20px" }}>
					{contactid && !isAdmin && !isTemp &&
					<Link onClick={( e ) => handleGoPage( 'colleaguesPage', e )}>
						<FormattedMessage id="viewColleagues"
										  defaultMessage="View all Colleagues" />
					</Link>}
					{contactid && isAdmin && !isTemp &&
					<Link onClick={( e ) => handleGoPage( 'manageColleaguesPage', e )}>
						<FormattedMessage id="manageColleagues"
										  defaultMessage="Manage Colleagues" />
					</Link>}
				</div>
				<LicensesTable />
				<div style={{ textAlign: "right", paddingTop: "10px", paddingBottom: "15px" }}>
					<a href="https://support.zemax.com/hc/sections/1500001481261" target="_blank" rel="noreferrer">
						<FormattedMessage id="moreInfoAboutLicenseManagement"
										  defaultMessage="More information about license management" />
					</a>
				</div>
			</div>
		</AppProvider>
	);
}
