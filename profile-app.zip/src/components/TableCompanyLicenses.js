import React, { useEffect, useState, useCallback } from "react";
import humanityDate from "../helpers/humanityDate";
import getStatusLicense from "../helpers/getStatusLicense";
import LinkToLicenseDetail from "./LinkToLicenseDetail";
import ManageButton from "./ManageButton";
import { useRecoilValue } from "recoil";
import { licensesObjectAtom, webRoleAdministrator } from "../atoms/profileAtom";
import adapterLicenseManage from "../helpers/adapterLicenceManager";
import usePagination from "./usePagination";
import LicenseTableBase from "./LicenseTableBase";
import sortingLicensesTableFull from "../helpers/sortingLicensesTableFull";
import { getButtonLicense, getLinkLicense } from "./getButtonsLicense";

export default function TableCompanyLicenses () {
	const [ adaptedLicensesData, setAdaptedLicensesData ] = useState( [] );
	const [ rows, setRows ] = useState( [] );
	const licensesObject = useRecoilValue( licensesObjectAtom );
	const isAdmin = useRecoilValue( webRoleAdministrator );

	const handleSort = useCallback(
		( index, direction ) => setAdaptedLicensesData( adaptedLicensesData => sortingLicensesTableFull( adaptedLicensesData, index, direction ) ),
		[ adaptedLicensesData ],
	);
	// console.log( licensesData );

	useEffect( () => {
		setAdaptedLicensesData( sortingLicensesTableFull( adapterLicenseManage( licensesObject.company_licenses ), 2, 'descending' ) );
		// console.log( adaptedLicensesData )

	}, [] )

	const
		{ paged, handlePagination, page, maxPages }
			= usePagination( rows, 10 )

	useEffect( () => {
		setRows( adaptedLicensesData.map( row => ([
				getButtonLicense( row, isAdmin )
				,
				getStatusLicense( row[ 1 ] ),
				humanityDate( row[ 1 ] ),
				getLinkLicense( row, isAdmin )
				,
				row[ 4 ],
				row[ 5 ],
				row[ 6 ],
				row[ 7 ],
				row[ 8 ],
			]
		) ) );

		//console.log( JSON.stringify(rows) );

	}, [ adaptedLicensesData ] )


	return (
		<LicenseTableBase adaptedLicensesData={adaptedLicensesData} handleSort={handleSort} rows={paged} page={page} maxPages={maxPages} handlePagination={handlePagination} />
	)
}

/*export default function TableCompanyLicensesOld () {
	const [ licensesData, setLicensesData ] = useState( {} );
	const [ licensesObject, setLicensesObject ] = useRecoilState( licensesObjectAtom );

	const [ sortedRows, setSortedRows ] = useState( null );
	const rows = sortedRows ? sortedRows : licensesData;

	console.log( licensesObject );

	useEffect( () => {
		setLicensesData( licensesObject.company_licenses );

	}, [] );

	const handleSort = useCallback(
		( index, direction ) => setSortedRows( sortValue( rows, index, direction ) ),
		[ rows ],
	);

	function sortValue(rows, index, direction) {
		console.log(direction)
		return [...rows].sort((rowA, rowB) => {
			const amountA = parseFloat(rowA[index]);
			const amountB = parseFloat(rowB[index]);

			return direction === 'descending' ? amountB - amountA : amountA - amountB;
		});
	}

	if ( licensesData && licensesData.length ) {
		// console.log( 'licensesData.length: ' + licensesData.length )

		const rows = licensesData.map( row => ([
			<ManageButton id={row.new_licensesid} />,
			getStatusLicense( row.new_supportexpires ),
			row.new_supportexpires,
			// humanityDate( row.new_supportexpires ),
			<LinkToLicenseDetail id={row.new_licensesid} name={row.new_licenseid} />,
			row[ 'zemax_nickname' ],
			row[ '_new_product_value@OData.Community.Display.V1.FormattedValue' ],
			row[ 'zemax_seattype@OData.Community.Display.V1.FormattedValue' ],
			row.new_usercount,
			row.new_endusercount
		]) )
		return (
			<DataTable title="Tile"
					   hideScrollIndicator="true"
					   columnContentTypes={[
						   'text',
						   'text',
						   'numeric',
						   'text',
						   'text',
						   'text',
						   'text',
						   'numeric',
						   'numeric'
					   ]}
					   headings={[
						   'Actions',
						   'Status',
						   'Support Expiry',
						   'License #',
						   'Nickname',
						   'Product',
						   'License Type',
						   'Seat Count',
						   'End User Count',
					   ]} rows={rows}
					   sortable={[false, false, false, false, false, false, false, false, false]}
					   onSort={handleSort}
					   defaultSortDirection="descending"
			/>
		)
	}

	return <></>

}*/
