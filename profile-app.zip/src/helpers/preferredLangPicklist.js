
export const preferredLangPicklist = [
	{
		id: 555030003,
		name_language: 'English',
		lang: 'en'
	},
	{
		id: 555030000,
		name_language: 'Japanese',
		lang: 'ja'
	},
	{
		id: 555030001,
		name_language: 'Simplified Chinese',
		lang: 'zh-CN'
	},
	{
		id: 555030002,
		name_language: 'Traditional Chinese',
		lang: 'zh-TW'
	}
]
