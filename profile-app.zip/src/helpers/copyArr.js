export default function ( arr ) {return JSON.parse( JSON.stringify( arr ) ); }
